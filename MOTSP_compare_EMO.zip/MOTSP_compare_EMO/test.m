% http://www.cercia.ac.uk/news/cec2017maooc/

% MOEAD-LWS run
clear all;
close all;
for r = 1 : 1
 
 main('-algorithm',@MOEADLWS,'-problem',@DTLZ2,'-N',100,'-M',2,'-run',r)    
% main('-algorithm',@NSGAII,'-problem',@DTLZ2,'-N',100,'-M',2,'-run',r)    
% main('-algorithm',@MOEADDE,'-problem',@DTLZ2,'-N',100,'-M',2,'-run',r) 
end