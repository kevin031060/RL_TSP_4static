% load static1.mat
% load tour1.mat
load static.mat
load tour.mat

tour = tour+1;

% plot3(static(1,:),static(2,:),static(3,:))

plot3(static(1,tour),static(2,tour),static(3,tour),'k')
hold on 
plot3(static(1,tour([1,30])),static(2,tour([1,30])),static(3,tour([1,30])),'k')
hold on 
scatter3(static(1,tour),static(2,tour),static(3,tour),'ko')

hold on
plot(static(1,tour),static(2,tour),'r')
hold on
plot(static(1,tour([1,30])),static(2,tour([1,30])),'r')
hold on 
scatter(static(1,tour),static(2,tour),'ro')
