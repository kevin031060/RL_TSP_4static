%% The angleSW function is used to compute the angle between two sets of vectors
% index == 1 returns an one-to-one angle set for setA and setB
% index == 2 returns an all-to-all angle matrix for setA and setB
% Made by Rui (ruiwangnudt@gmail.com)
% 2017.03.30, at NUDT.

function degreeMatrix = angleSW(setA,setB,index)
if nargin < 3, index=2; end
[setA_row_num,M] = size(setA);
[setB_row_num,M] = size(setB);
switch index
    case 1
        %setA = setA./rep(sum(setA,2),[1,M]);
        vector1 = setB;
        vector2 = setA;
        nomv1 = vector1./rep(sqrt(sum(vector1.^2,2)),[1,M]);
        nomv2 = vector2./rep(sqrt(sum(vector2.^2,2)),[1,M]);
        xtheta = acosd(sum(nomv1.*nomv2,2));
        degreeMatrix = xtheta;
    case 2
        %setA = setA./rep(sum(setA,2),[1,M]);
        degreeMatrix=zeros(setA_row_num,setB_row_num);
        for iw = 1:setB_row_num
            vector1 = rep(setB(iw,:),[setA_row_num,1]);
            vector2 = setA;
            nomv1 = vector1./rep(sqrt(sum(vector1.^2,2)),[1,M]);
            nomv2 = vector2./rep(sqrt(sum(vector2.^2,2)),[1,M]);
            xtheta = acosd(sum(nomv1.*nomv2,2));
            degreeMatrix(:,iw) = xtheta;
        end
end

end


