function MOEADLWS(Global)
% <algorithm> <H-N>
% Localized weighted sum method for many-objective optimization, by Wang et
% al. 2017 TEVC
%
% delta --- 0.9 --- The probability of choosing parents locally
% nr    ---   2 --- Maximum number of solutions replaced by each offspring
% operator      --- DE

%--------------------------------------------------------------------------
% The copyright of the PlatEMO belongs to the BIMK Group. You are free to
% use the PlatEMO for research purposes. All publications which use this
% platform or any code in the platform should acknowledge the use of
% "PlatEMO" and reference "Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu
% Jin, PlatEMO: A MATLAB Platform for Evolutionary Multi-Objective
% Optimization, 2016".
%--------------------------------------------------------------------------

% Copyright (c) 2016-2017 BIMK Group

%% Parameter setting
%delta = Global.ParameterSet(0.9);
[delta,nr] = Global.ParameterSet(0.9,2);

%% Generate the weight vectors
[W,Global.N] = UniformPoint(Global.N,Global.M);
T = ceil(Global.N/10);
%% parameters transfer
M = Global.M;
N = Global.N;

jointWnum = N;
jointFnum = N;
jointWD = W;
jointW = 1./(W+0.0000001);
w_angleWS = jointWD;  % the weight used to compute angle between S and W
w_angle_ww = jointWD; % the weight used to compute angle between W and W
w_scalr_ws = jointW;  % the weight used in the WS scalarizing function
wofw = angleSW(w_angle_ww,w_angle_ww);
sortedwofw = sort(wofw);
wZoneDef = (mean(sortedwofw(2:M+1,:)));
wZone = wZoneDef;
scalarMatrix = zeros(2*jointWnum,jointWnum);
zref = -0.00001;

%% Detect the neighbours of each solution
B = pdist2(W,W);
[~,B] = sort(B,2);
B = B(:,1:T);

%% Generate random population
Population = Global.Initialization();

jointP = Population.decs;
jointF = Population.objs;
offspringdec = jointP;
offspringobv= jointF;
nVar = size(Population(1).dec,2);
bestobjv = Inf*ones(1,M);
bestphen = NaN*ones(1,nVar);
Normbestobjv = Inf*ones(1,M);

%% Optimization
while Global.NotTermination(Population)
    % For each solution
    for i = 1 : Global.N
        % Choose the parents
        if rand < delta
            P = B(i,randperm(size(B,2)));
        else
            P = randperm(Global.N);
        end
        % Generate an offspring
        %OffspringLWS = Global.Variation(Population([i,P(1:2)]),1,@DE);
        OffspringLWS = Global.Variation(Population(P(1:2)),1);
        offspringdec(i,:) = OffspringLWS.dec;
        offspringobv(i,:) = OffspringLWS.obj;
    end
    %% Environment Selection
    jointPall = [jointP;offspringdec];
    jointFAll = [jointF;offspringobv];
    normjointFAll = normliseData(jointFAll,jointFAll);
    for iwindex = 1:N
        scalarMatrix(:,iwindex)  =  sum(rep(w_scalr_ws(iwindex,:),[2*jointFnum,1]).* abs(normjointFAll-zref), 2);
    end
    angleSofW = angleSW(normjointFAll,w_angleWS);
    labelneiSofW = angleSofW<rep(wZone,[2*jointFnum,1]);
    newscalarMatrix = scalarMatrix.*labelneiSofW;
    newscalarMatrix(newscalarMatrix ==0) = max(max(newscalarMatrix))+1;

    [~,indexSofW] = min(newscalarMatrix,[],1);
    jointP = jointPall(indexSofW,:);
    jointF = jointFAll(indexSofW,:);
    normjointF = normjointFAll(indexSofW,:);
    Population = INDIVIDUAL(jointP,jointF);
    %%
    Cobjvix = find_nd(jointF);
    Hobjv =  jointF(logical(Cobjvix),:);
    NormHobjv =  normjointF(logical(Cobjvix),:);
    HP = jointP(logical(Cobjvix),:);
    [ix,bestix] = find_nd(Hobjv,bestobjv);
    bestobjv = [bestobjv(logical(bestix),:) ; Hobjv(logical(ix),:)];
    Normbestobjv = [Normbestobjv(logical(bestix),:) ; NormHobjv(logical(ix),:)];
    bestphen = [bestphen(logical(bestix),:) ; HP(logical(ix),:)];
    bestNum = size(bestobjv,1);
    if bestNum>N
        [Normbestobjv,index] = reducer(Normbestobjv, M, N);
        bestobjv = bestobjv(index,:);
        bestphen = bestphen(index,:);
        Population = INDIVIDUAL(bestphen,bestobjv);
    end
end
end